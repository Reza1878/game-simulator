import React from "react";

function IconDisplay() {
  return <div>IconDisplay</div>;
}

export default IconDisplay;
