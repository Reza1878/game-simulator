export const BASE_PRICING_BLANK_PAGE = {
  name: "",
  description: "",
  price: 0,
  user_tier_id: null,
  interval: null,
  features: "",
};
