import AdminLayout from "./AdminLayout";
import GuestLayout from "./GuestLayout";

export { GuestLayout, AdminLayout };
