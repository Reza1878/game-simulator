export const BASE_BAN_AMOUNT_BLANK_PAGE = {
  ban_count: null,
};
