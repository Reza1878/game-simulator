export const TEAM_BASE_BLANK_FORM = {
  name: null,
  side: null,
};
