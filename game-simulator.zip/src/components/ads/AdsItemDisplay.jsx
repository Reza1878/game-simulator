import React from "react";

function AdsItemDisplay() {
  return <div>AdsItemDisplay</div>;
}

export default AdsItemDisplay;
