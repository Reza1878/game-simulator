import SettingsItemPage from "./SettingsItemPage";
import SettingUpdatePage from "./SettingUpdatePage";

export { SettingsItemPage, SettingUpdatePage };
