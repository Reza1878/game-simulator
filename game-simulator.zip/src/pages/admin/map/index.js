import MapDetailPage from "./MapDetailPage";
import MapUpdatePage from "./MapUpdatePage";

export { MapDetailPage, MapUpdatePage };
