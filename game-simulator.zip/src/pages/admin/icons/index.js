import IconsCreatePage from "./IconsCreatePage";
import IconsListPage from "./IconsListPage";
import IconsDetailPage from "./IconsDetailPage";
import IconsUpdatePage from "./IconsUpdatePage";

export { IconsCreatePage, IconsListPage, IconsDetailPage, IconsUpdatePage };
