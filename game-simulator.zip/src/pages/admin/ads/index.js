import AdsCreatePage from "./AdsCreatePage";
import AdsListPage from "./AdsListPage";
import AdsUpdatePage from "./AdsUpdatePage";
import AdsDetailPage from "./AdsDetailPage";

export { AdsCreatePage, AdsListPage, AdsUpdatePage, AdsDetailPage };
