import TeamCreatePage from "./TeamCreatePage";
import TeamListPage from "./TeamListPage";
import TeamUpdatePage from "./TeamUpdatePage";

export { TeamCreatePage, TeamListPage, TeamUpdatePage };
