import BanAmountCreatePage from "./BanAmountCreatePage";
import BanAmountListPage from "./BanAmountListPage";
import BanAmountUpdatePage from "./BanAmountUpdatePage";

export { BanAmountCreatePage, BanAmountListPage, BanAmountUpdatePage };
