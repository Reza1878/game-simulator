import HeroesCreatePage from "./HeroesCreatePage";
import HeroesUpdatePage from "./HeroesUpdatePage";
import HeroesListPage from "./HeroesListPage";
import HeroesDetailPage from "./HeroesDetailPage";

export { HeroesCreatePage, HeroesDetailPage, HeroesListPage, HeroesUpdatePage };
