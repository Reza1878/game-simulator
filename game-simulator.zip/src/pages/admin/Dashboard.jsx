import { BasePage } from "@/components/common";
import React from "react";

function Dashboard() {
  return <BasePage title="Dashboard" />;
}

export default Dashboard;
