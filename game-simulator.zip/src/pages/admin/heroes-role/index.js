import HeroesRoleListPage from "./HeroesRoleListPage";
import HeroesRoleCreatePage from "./HeroesRoleCreatePage";
import HeroesRoleUpdatePage from "./HeroesRoleUpdatePage";

export { HeroesRoleListPage, HeroesRoleCreatePage, HeroesRoleUpdatePage };
