import Home from "./Home";
import Pricing from "./Pricing";
import Suggestions from "./Suggestions";
export { Home, Pricing, Suggestions };
