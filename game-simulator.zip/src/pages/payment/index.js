import CancelPayment from "./CancelPayment";
import SuccessPayment from "./SuccessPayment";

export { CancelPayment, SuccessPayment };
