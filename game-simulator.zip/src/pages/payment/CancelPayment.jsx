import React from "react";

function CancelPayment() {
  return <div className="text-white">Payment Canceled</div>;
}

export default CancelPayment;
