import React from "react";

function SuccessPayment() {
  return <div className="text-white">Payment Success</div>;
}

export default SuccessPayment;
