import ContactUsForm from "@/components/ContactUsForm";
import React from "react";

function Suggestions() {
  return (
    <div className="max-w-5xl w-full mx-auto p-6">
      <ContactUsForm />
    </div>
  );
}

export default Suggestions;
