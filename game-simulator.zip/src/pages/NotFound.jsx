import React from "react";

function NotFound() {
  return (
    <div className="min-h-[50vh] flex justify-center items-center">
      <p className="text-white text-2xl text-center">Not found</p>
    </div>
  );
}

export default NotFound;
